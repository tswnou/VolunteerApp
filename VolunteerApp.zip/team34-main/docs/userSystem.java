import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class userSystem{
    private List<User> users;
     static class user{
        private string password;
        private string  username;

        user(string password, string username){
            this.password = password;
            this.username = username;
        }
     }

     public UserSystem(){
        users = new ArrayList<> ();
     }

     private boolean isValidPassword(String password){
        return password.length() > 8 &&password.matches(".*[A-Z].*") && password.matches(".*[a-z].*") && password.matches(".*\\d.*") && password.matches(".*[!@#$%*.,].*");

     }


    private boolean isValidUsername(String username){
        return username.matches(".*[a-z].*") && username.matches(".*[A-Z].*") && username.matches(".*\\d.*");
    }

    private boolean UserExist(String username){
        for (User user : users){
            if(user.username.equals(username)){
                return true;
            }else{
                return false;
            }
        }

    }

   

    public boolean createUser(String username, String password){
        users.add(new User(username, password));
        System.out.println("The acount has been created successfully");
        return true;

    }

    private boolean login(String username, String password ){
        for( User user : users){
            if(user.username.equals(username) && user.password.equals(password)){
                return true;
            }else{
                return false;
            }
        }
    }

    private void displayMessage(){
        System.out.println(message);
    }

}