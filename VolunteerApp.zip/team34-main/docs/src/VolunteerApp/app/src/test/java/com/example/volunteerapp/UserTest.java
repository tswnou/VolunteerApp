import org.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UserTest {
    @Test
    void testConnection() {
        User user = new User(1, "user1", "pass123");
        assertTrue(user.connection("user1", "pass123"), "Connection should be a success with correct credentials");
        assertFalse(user.connection("user1", "wrong1"), "Connection should fail");
    }

    @Test
    void testDisconnect() {
        User user = new User(1, "user1", "pass123");
        user.disconnect();
        assertEquals("The user user1 has disconnected", System.out.getLastPrintedLine(), "Disconnect message should show");
    }
}