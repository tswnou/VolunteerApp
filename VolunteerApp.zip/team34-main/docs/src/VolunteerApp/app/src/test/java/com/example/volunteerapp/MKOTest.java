import org.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MKOTest {
    @Test
    void testAddVolunteer() {
        MKO mko = new MKO(1, "MKO_NAME", "Papagos", 123456789, "mko@gmail.com", 0);
        Volunteer volunteer = new Volunteer(1, "Christina123", "pass123",  "christina@gmail.com", "Christina Karagianni");
        mko.addVolunteer(volunteer);
        assertTrue(mko.getVolunteers().contains(volunteer), "Volunteer should be added to the list.");

    }

    @Test
    void testAddDonation() {
        MKO mko = new MKO(1, "MKO_NAME", "Papagos", 123456789, "mko@gmail.com", 0);
        mko.addDonation(50);
        assertEquals(50, mko.getTotalDonations(), "Donation amount should be added to total donations");


    }

    @Test
    void testDisplayVolunteers() {
        MKO mko = new MKO(1, "MKO_NAME", "Papagos", 123456789, "mko@gmail.com", 0);
        Volunteer volunteer = new Volunteer(1, "Christina123", "pass123",  "christina@gmail.com", "Christina Karagianni");
        mko.addVolunteer(volunteer);
        mko.displayVolunteers();
        assertEquals("MKO Volunteers: Name: Christina Karagianni, Email: christina@gmail.com", System.out.getLastPrintedLine());
    }
}