import org.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PaymentSystemTest {
    @Test
    void testAddPayment() {
        PaymentSystem system = new PaymentSystem();
        PaymentSystem.Payment payment = system.new Payment("Christina Karagianni", 50, "Credit Card");
        system.addPayment(payment);
        assertEquals(1, system.getPayments().size(), "Payment should be added to the list.");
    }

    @Test
    void testProcessPayment() {
        PaymentSystem system = new PaymentSystem();
        PaymentSystem.Payment payment = system.new Payment("Christina Karagianni", 50, "Credit Card");
        assertTrue(system.processPayment(payment), "Payment should be processed with success");
        assertTrue(payment.isProcessed(), "Payment should be marked as Processed");
    }
}