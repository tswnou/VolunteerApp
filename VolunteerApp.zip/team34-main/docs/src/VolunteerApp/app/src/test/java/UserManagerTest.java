package com.example.volunteerapp;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.test.core.app.ApplicationProvider;
import jdk.jfr.Timestamp;
import org.junit.Before;
import static org.junit.Assert.*;

import java.beans.Transient;

public class UserManagerTest{

    private UserManager userManager;

    @Before
    public void setUp(){
        Context context = ApplicationProvider.getApplicationContext();
        userManager = new UserManager(context);
        userManager.clearUserData();

    }

    @Test
    public void testRegisterUer(){
        boolean result = userManager.registerUser("testUser", "testPass");
        assertTrue(result);

    }

    @Test
    public void testRegisterDuplicateUser(){
        userManager.registerUser("testUser", "testPass");
        boolean result = userManager.registerUser("testUser", "testPass");
        assertFalse(result);
    }

    @Test
    public void testLoginUser(){
        userManager.registerUser("testUser", "testPass");
        boolean result = userManager.loginUser("testUser", "testPass");
        assertTrue(result);
    }

    @Test
    public void testLoginInvalidUser(){
        boolean result = userManager.loginUser("invalidUser", "invalidPass");
        assertFalse(result);

    }
}
