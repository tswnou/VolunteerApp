package com.example.volunteerapp;
import androidx.content.Context;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.juint.rules.ActivityScenarioRule;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.matcher.ViewMatchers;
import androidx.test.espresso.assertion.ViewAssertions;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;


import static androidx.test.espresso.acion.ViewActions.typeText;

public class LoginActivity{
    public ActivityScenarioRule<LoginActivity> activityRule =
            new ActivityScenarioRule<>(LoginActivity.class);

    public void setUp(){
        Context context = ApplicationProvider.getApplicationContext();
        UserManager userManager = new UserManager(context);
        userManager.clearUserData();
        userManager.registerUser("testUser", "testPass");
    }


    public void testSuccessfullLogin(){
        Espresso.onView(ViewMatchers.withld(R.id.et_username))
                .perform(typeText("testUser"), ViewActions.closeSoftKeyboard());


        Espresso.onView(ViewMatchers.withld(R.id.et_password))
                .perform(typeText("testPass"),ViewActions.closeSoftKeyboard());


        Espresso.onView(ViewMatchers.withld(R.id.btn_login)) .perform(ViewActions.click());

        Espresso.onView(ViewMatchers.withText("Login successfull"))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
    }

    public void testInvalidLogin(){
        Espresso.onView(ViewMatchers.withld(R.id.et_username))
                .perform(typeText("wrongUser"), ViewActions.closeSoftKeyboard());

        Espresso.onView(ViewMatchers.withld(R.id.et_password))
                .perform(typeText("wrongPass"), ViewActions.closeSoftKeyboard());


        Espresso.onView(ViewMatchers.withld(R.id.btn_login)).perform(ViewActions.click());


        Espresso.onView(ViewMatchers.withText("Invalid credentials!"))
                .check(ViewAssertions.matches(ViewMatchers.isDisplayed()));

    }
}

