import org.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

class VolunteerTest {
    @Test
    void testDonation() {
        Volunteer volunteer = new Volunteer(1, "Christina", "pass123",  "christina@gmail.com", "Christina Karagianni");
        volunteer.donation(50);
        assertEquals("The User: Christina Karagianni donated: 50.0 euros.", System.out.getLastPrintedLine(), "Donation message should be ok");
    }
    @Test
    void testParticipation() {
        Volunteer volunteer = new Volunteer(1, "Christina", "pass123",  "christina@gmail.com", "Christina Karagianni");
        Action action = new Action(1, "Tree Planting", new Date(), "Penteli", 10);

        volunteer.participation(action);
        assertTrue(volunteer.getParticipations().contains(action), "Action should be added to the volunteer's participations.");
    }
}