package com.example.volunteerapp;

import java.util.ArrayList;
import java.util.List;


//Manages actions created by NGOs


public class NGOManager {

    private List<Action> ngoActions;

    
    //initializes the NGOManager with an empty list of actions
    

    public NGOManager() {
        ngoActions = new ArrayList<>();
    }

    /**
     * adds a new action to the NGO's managed actions
     *
     * @param action the action to add
     */


    public void addAction(Action action) {
        ngoActions.add(action);
    }

    /**
     * retrieves all actions created by the NGO
     *
     * @return list of actions
     */


    public List<Action> getAllActions() {
        return new ArrayList<>(ngoActions);
    }

    /**
     * edits an existing action
     *
     * @param actionId The ID of the action to edit
     * @param newName The new name for the action
     * @param newDescription The new description for the action
     * @param newMaxParticipants The new maximum participants
     * @return true if the action was edited successfully false otherwise
     */


    public boolean editAction(String actionId, String newName, String newDescription, int newMaxParticipants) {
        for (Action action : ngoActions) {
            if (action.getId().equals(actionId)) {
                action.setName(newName);
                action.setDescription(newDescription);
                action.setMaxParticipants(newMaxParticipants);
                return true;
            }
        }
        return false;
    }

    /**
     *   deletes an action created by the NGO
     *
     * @param actionId the ID of the action to delete
     * @return true if the action was deleted successfully   false otherwise
     */


    public boolean deleteAction(String actionId) {
        return ngoActions.removeIf(action -> action.getId().equals(actionId));
    }


}