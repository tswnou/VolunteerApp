import java.util.ArrayList;
import java.util.List;

public class Volunteer extends User{
    //private int id;
    //private String username;
    //private String password;
    private String email;
    private String name;
    private List<Action> participations;

    public Volunteer(int id, String username, String password, String email, String name) {
        super(id, username, password);
        this.email = email;
        this.name = name;
        this.participations = new ArrayList<>();

    }

    public List<Action> getParticipations() {
        return participations;
    }

    //get-set email
    public String getEmail(){
        return email;
    }

    public void setEmail(String email){
        this.email = email;
    }


    //get-set name 
    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name; 
    }


    //donation 
    public void donation(double amount){
        if (amount > 0){
            System.out.println("The user : " + this.name + " donated : " + amount + " euros.");

        }else {
            System.out.println("ERROR! Amount must be positive to process a donation.");
        }

    }

    //Available actions 
    public void AvailableActions(List<Action> availableActions){
        System.out.println("Available Actions : ");
        for (Action action : availableActions){
            System.out.println(action.getTitle());

        }
    }


    public void participation(Action action){
        if(!participations.contains(action)){
            action.Signup(this);
            participations.add(action);
        } else{
            System.out.println("You have already signed up for this action");
        }
    }

    public void DeleteAction(Action action){
        if (participations.contains(action)){
            participations.remove(action);
            System.out.println("Your participation in action : " + action.getTitle() + " was cancelled.");
            action.setAvailability(action.getAvailability() + 1);
        } else{
            System.out.println("You have not signed up for this action");

        }
        
    }


}