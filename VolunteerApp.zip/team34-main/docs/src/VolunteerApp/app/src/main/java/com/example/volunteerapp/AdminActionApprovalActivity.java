package com.example.volunteerapp;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.stream.Collectors;

public class AdminActionApprovalActivity extends AppCompatActivity{
    private ListView LvPendingActions;
    private Button btnApprove;
    private Button btnReject;

    private AdminManager adminManager;
    private List<Action> pendingActions;
    private int selectedActionIndex = 1;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_action_approval);

        IvPendingActions = findViewByld(R.id.lv_pending_actions);
        btnApprove = findViewByld(R.id.btn_aprrove_action);
        btnReject = findViewByld(R.id.btn_reject_action); 

        adminManager = new AdminManager();
        Load pendingActions();

        btnApprove.setOnClickListener(v->{
            if(selectedActionIndex == -1){
                Toast.makeText(this, "Please select an action to approve", Toast.LENGTH_SHORT).show();
                return;
            }

            Action actionToApprove = pendingActions.get(selectedActionIndex);
            adminManager.approveAction(actionToApprove.getId());
            Toast.makeText(this, "Action Approved", Toast.LENGTH_SHORT).show();
            loadPendingActions();
                
            
        });

        btnReject.setOnClickListener(v ->{
            if(selectedActionIndex == -1){
                Toast.makeText(this, "Please select an action to reject", Toast.LENGTH_SHORT).show();
                return;
            }
            Action actionToReject = pendingActions.get(selectedActionIndex);
            adminManager.rejectAction(actionToReject.getId());
            Toast.makeText(this, " Action Rejected", Toast.LENGTH_SHORT).show();
            loadPendingActions();
        });

        IvPendingActions.setOnItemClickListener((parent, view, position , id) -> selectedActionIndex = position);
         } 
        private void loadPendingActions(){

        
            pendingActions = adminManager.getPendingActions();
            List<String>actionNames = pendingActions.stream()
                .map(Action::getName)
               .collect(Collectors.toList());


            ArrayAdapter<String>adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_choice,
                actionNames
            );
            
            IvPendingActions.setAdapter(adapter);
            IvPendingActions.setChoiceModel(ListView.CHOISE_MODE_SINGLE);

            selectedActionIndex = -1;
        }
    }




    

