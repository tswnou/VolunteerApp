package com.example.volunteerapp;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages customization of the home menu for NGOs and volunteers.
 */
public class HomeMenuManager {
    private List<String> menuOptions;

    /**
     * Initializes the HomeMenuManager with default options.
     */
    public HomeMenuManager() {
        menuOptions = new ArrayList<>();
        menuOptions.add("View Actions");
        menuOptions.add("Manage Profile");
        menuOptions.add("Statistics");

    }

    /**
     * Retrieves the current menu options.
     *
     * @return List of menu options.
     */
    public List<String> getMenuOptions() {
        return new ArrayList<>(menuOptions);
    }

    /**
     * Adds a new menu option.
     *
     * @param option The menu option to add.
     * @return True if the option was added successfully, false if it already exists.
     */
    public boolean addMenuOption(String option) {
        if (!menuOptions.contains(option)) {
            menuOptions.add(option);
            return true;
        }
        return false;
    }

    /**
     * Removes a menu option.
     *
     * @param option The menu option to remove.
     * @return True if the option was removed successfully, false if it does not exist.
     */
    public boolean removeMenuOption(String option) {
        return menuOptions.remove(option);
    }

    /**
     * Updates an existing menu option.
     *
     * @param oldOption The menu option to update
     * @param newOption The new value for the menu option.
     * @return True if the update was successful, false if the old option does not exist.
     */
    public boolean updateMenuOption(String oldOption, String newOption) {
        int index = menuOptions.indexOf(oldOption);
        if (index != -1) {
            menuOptions.set(index, newOption);
            return true;
        }
        return false;
    }
}
