package com.example.volunteerapp;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Displays detailed information about a selected action and allows participation
 */
public class ActionDetailsActivity extends AppCompatActivity {
    private TextView tvActionName;
    private TextView tvActionDescription;
    private TextView tvActionParticipants;
    private Button btnJoinAction;

    private Action selectedAction;
    private ActionManager actionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_details);
        tvActionName = findViewById(R.id.tv_action_name);
        tvActionDescription = findViewById(R.id.tv_action_description);
        tvActionParticipants = findViewById(R.id.tv_action_participants);
        btnJoinAction = findViewById(R.id.btn_join_action);
        actionManager = new ActionManager();
        String actionId = getIntent().getStringExtra("ACTION_ID");
        selectedAction = actionManager.getAvailableActions().stream().filter(action->action.getId().equals(actionId)).findFirst().orElse(null);
        if (selectedAction != null) {
            tvActionName.setText(selectedAction.getName());
            tvActionDescription.setText(selectedAction.getDescription());
            tvActionParticipants.setText("Participants: " + selectedAction.getCurrentParticipants() + "/" + selectedAction.getMaxParticipants());
            btnJoinAction.setOnClickListener(v->{
                boolean success = actionManager.participateInAction(selectedAction.getId());
                if (success) {
                    Toast.makeText(ActionDetailsActivity.this, "Unable to join. The action may be full.", Toast.LENGTH_SHORT).show);

                }
            });

        }
        else {
            Toast.makeText(this, "Action not found.", Toast.LENGTH_SHORT).show();
            finish();
        }

    }
}
