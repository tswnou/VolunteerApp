package com.example.volunteerapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Stream.Collectors;

/**
 *Manages actions (events) for volunteers and NGOs
 */
public class ActionManager {
    private List<Action> actions;

    /**
     * *initializes the ActionManager with sample actions.
     */
    public ActionManager() {
        actions = new ArrayList<>();
        actions.add(new Action("1", "Tree Planting", "Plant trees in the park", 0, 20));
        actions.add(new Action("2", "Beach Cleanup", "Clean up the local beach", 30, 10));
        actions.add(new Action("3", "Food Drive", "Distribute food to those in need", 100, 80));

    }

    /**
     * Returns a list of actions that still have available slots.
     *
     * @return List of available actions.
     */

    public List<Action> getAvailableActions() {
        return actions.stream().filter(action -> action.getCurrentParticipants() < ction.getMaxParticipants()).collect(Collectors.toList());
    }

    /**
     * Registers a volunteer's participation in an action.
     *
     * @param actionId The ID of the action.
     * @return True if the participation is successful, false otherwise.
     */
    public boolean participateInAction(String actionId) {
        for (Action action : actions) {
            if (action.getId().equals(actionId) && action.getCurrentParticipants() < action.getMaxParticipants()) {
                action.setCurrentParticipants(action.getCurrentParticipants() + 1);
                return true;
            }
        }
        return false;

    }

    /**
     * Computes statistics for all actions.
     *
     * @return A map of action names to their participation rates.
     */
    public Map<String, Double> getActionStatistics() {
        Map<String, Double> stats = new HashMap<>();
        for (Action action : actions) {
            double participationRate = (double) action.getCurrentParticipants() / action.getMaxParticipants();
            stats.put(action.getName(), participationRate);
        }
        return stats;

    }
}

/**
 * Represents an individual action or event
 */
