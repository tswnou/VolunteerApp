import java.util.ArrayList;
import java.util.List;

public class PaymentSystem {

    private List<Payment> payments;


    public PaymentSystem(){
        this.payments = new ArrayList<>();
    }

    public void addPayment(Payment payment){
        payments.add(payment);
        System.out.println("Payment added : " + payment);
    }
    public List<Payment> getPayments() {
        return payments;
    }
    public boolean processPayment(Payment payment){
        if (payment.getAmount() > 0){
            payment.setProcessed(true);
            addPayment(payment);
            System.out.println("System processed : " + payment);
            return true;
        }else{
            System.out.println("Payment failed : Invalid amount.");
            return false;
        }
    }

    public void displayPayments(){
        System.out.println("List of payments : ");
        for (Payment payment : payments){
            System.out.println(payment);
        }
    }

    class Payment {
        private String payer;
        private double amount;
        private String paymentMethod;
        private boolean isProcessed;

        public Payment(String payer , double amount , String paymentMethod){
            this.payer = payer;
            this.amount = amount;
            this.paymentMethod = paymentMethod;
            this.isProcessed = false;
        }



        public String getPayer(){
            return payer;
        }

        public void setPayer(String payer){
            this.payer = payer;
        }

        public double getAmount(){
            return amount;
        }

        public void setAmount(double amount){
            this.amount = amount;
        }

        public String getPaymentMethod(){
            return paymentMethod;
        }

        public void setPaymentMethod(String paymentMethod){
            this.paymentMethod = paymentMethod;
        }

        public boolean isProcessed(){
            return isProcessed;
        }

        public void setProcessed(boolean isProcessed){
            this.isProcessed = isProcessed;
        }

        @Override
        public String toString(){
            return "Payer : " + payer + ", Amount : " + amount + ", Method : " + paymentMethod + " , Processed : " + isProcessed;
        } 

    



    }

  
}