import java.util.ArrayList;
import java.util.List;

public class userSystem{
    private List<User> users;
    static class user{
        private String password;
        private String  username;

        user(String password, String username){
            this.password = password;
            this.username = username;
        }
    }

    public void UserSystem(){
        users = new ArrayList<> ();
    }

    private boolean isValidPassword(String password){
        return password.length() > 8 &&password.matches(".*[A-Z].*") && password.matches(".*[a-z].*") && password.matches(".*\\d.*") && password.matches(".*[!@#$%*.,].*");

    }


    private boolean isValidUsername(String username){
        return username.matches(".*[a-z].*") && username.matches(".*[A-Z].*") && username.matches(".*\\d.*");
    }

    private boolean UserExist(String username){
        for (User user : users){
            if(user.getUsername().equals(username)){
                return true;
            }else{
                return false;
            }
        }
        return false;
    }



    public boolean createUser(int id, String username, String password){
        users.add(new User(id, username, password));
        System.out.println("The acount has been created successfully");
        return true;

    }

    private boolean login(String username, String password ){
        for( User user : users){
            if(user.getUsername().equals(username) && user.getPassword().equals(password)){
                return true;
            }else{
                return false;
            }
        }
        return false;
    }

    private void displayMessage(){
        System.out.println("message");
    }
}