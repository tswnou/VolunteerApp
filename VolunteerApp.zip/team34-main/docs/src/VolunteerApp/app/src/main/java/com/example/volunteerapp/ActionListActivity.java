package com.example.volunteerapp;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Displays a list of available actions for volunteers to join.
 */
public class ActionListActivity extends AppCompatActivity {
    private ListView IvActions;
    private ActionManager actionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_list);
        actionManager = new ActionManager();
        lvActions = findViewById(R.id.lv_actions);
        List<Action> availableActions = actionManager.getAvailableActions();
        List<String> actionNames = availableActions.stream().map(Action::getName).collect(Collectors.toList());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, actionNames);
        lvActions.setAdapter(adapter);
        lvActios.setAdapter(adapter);
        lvActions.setOnItemClickListener((AdapterView<?> parent, android.view.View view, int position, long id))->{
            String selectedActionName = actionNames.get(position);
            Action selectedAction = availableActions.get(position);
            boolean success = actionManager.participateInAction(selectedAction.getId());
            if (success) {
                Toast.makeText(ActionListActivity.this, "Unable to join: " + selectedActionName + " Action might be full."), Toast.LENGTH_SHORT).show();
            }
        });
    }
}