package com.example.volunteerapp;

import java.util.HashMap;
import java.util.Map;

 
// Manages donations for actions



public class DonationManager{
    
    
    private Map <String, Double> actionDonations;

    //initializes the donationmanager

    public DonationManager(){
        actionDonations = new HashMap<>();
    }


    /**
     * processes a donation for a specific action
     * 
     * @param actionId The ID of the action to donate to 
     * @param amount the donation amount 
     * @return True if  the donation is successful, false if is invalid 
     * 
     */

    public boolean donate(String actionId, double amount){
        if (amount <= 0 ){
            return false;  // invalid donation amount
        }

        actionDonations.put(actionId. actionDonations, getOrDefault(actionId, 0.0)+ amount );
        return true;
    } 


    /**
     * Retrieves the total donations for a specific action
     *    
     * @param actionId the id of the action
     * @return Total donation amount 
     */


    public double getTotalDonations(String actionId){
        return actionDonations.getOrDefault(actionId, 0.0);
    }

}