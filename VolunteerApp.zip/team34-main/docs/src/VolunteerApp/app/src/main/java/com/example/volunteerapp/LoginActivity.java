package com.example.usermanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.awt.RadialGradientPaint;

import com.example.usermanagement.UserManagement;

public class LoginActivity extends AppCompatActivity{

    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private UserManager userManager;

    @Override
    protected void onCreate(Bundle savedInstanceState ){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewByld(R.id.et_username);
        etPassword = findViewByld(R.id.et_password);
        btnLogin = findViewByld(R.id.btn_login);

        userManager = new UserManagement(this);

        btnLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if(username.isEmpty() || password.isEmpty()){
                    Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isLoggedin = userManager.loginUser(username, password);
                if (isLoggedin){
                    Toast.makeText(LoginActivity.this, "Login successfull!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
