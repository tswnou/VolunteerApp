import java.util.ArrayList;
import java.util.List;

public class MKO{
    private int id;
    private String name;
    private String address;
    private int phonenumber;
    private String email;
    private List<Volunteer> volunteers;
    private List<Action> actions;
    private double totalDonations;

    public MKO(int id, String name, String adress, int phonenumber, String email, double totalDonations) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.phonenumber = phonenumber;
        this.email = email;
        this.totalDonations = 0.0;
        this.volunteers = new ArrayList<>();
        this.actions = new ArrayList<>();
    }


    //get-set id
    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }



    //get-set name
    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }



    //get-set adress
    public String getAdress(){
        return address;
    }

    public void setAddress(String address){
        this.address = address;
    }



    //get-set phonenumber
    public int getPhonenumber(){
        return phonenumber;
    }

    public void setPhonenumber(int phonenumber){
        this.phonenumber = phonenumber;
    }




    //get-set email
    public String getEmail(){
        return email;
    }

    public void setEmail(String email){
        this.email = email;
    }



    //get-set volunteers list
    public List<Volunteer> getVolunteers(){
        return volunteers;
    }

    public List<Action> getActions(){
        return actions;
    }



    //get-set total donations
    public double getTotalDonations(){
        return totalDonations;
    }

    public void getTotalDonations(double totalDonations){
        this.totalDonations = totalDonations;
    }



    //add volunteer to list
    public void addVolunteer(Volunteer volunteer){
        if(!volunteers.contains(volunteer)){
            volunteers.add(volunteer);
        }else {
            System.out.println("The volunteer already exists.");
        }

    }

    //add action to list
    public void addAction (Action action){
        if (!actions.contains(action)){
            actions.add(action);
        } else {
            System.out.println("The action already exists.");
        }
    }


    //add donation
    public void addDonation(double amount){
        if(amount > 0){
            totalDonations += amount;
            System.out.println("A new donation was added : " + amount + "euros. Total Donations : " + totalDonations + ".");
        } else{
            System.out.println("ERROR! The amount must be over 0.");
        }
    }

    //provoli olon ton ethelodon
    public void displayVolunteers(){
        System.out.println("MKO Volunteers : ");
        for(Volunteer volunteer : volunteers){
            System.out.println("Name: " + volunteer.getName() + " , Email: " + volunteer.getEmail());

        }
    }


    //provoli olon ton draseon 
    public void displayActions(){
        System.out.println("MKO Actions : ");
        for (Action action : actions ){
            System.out.println("Title : " + action.getTitle() + " , availability : " + action.getAvailability());

        }
    }

}