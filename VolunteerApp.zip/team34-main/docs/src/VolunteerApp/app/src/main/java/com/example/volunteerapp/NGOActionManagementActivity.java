package com.example.volunteerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.stream.Collectors;




//Handles the management of actions created by an NGO.


public class NGOActionManagementActivity extends AppCompatActivity {

    private ListView lvNGOActions;
    private Button btnAddNewAction;


    private NGOManager ngoManager;
    private List<Action> ngoActions;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ngo_action_management);

        // initializes views

        lvNGOActions = findViewById(R.id.lv_ngo_actions);
        btnAddNewAction = findViewById(R.id.btn_add_new_action);

        // initializes NGOManager

        ngoManager = new NGOManager();

        // loads actions

        loadNGOActions();

        // handles adds new action button

        btnAddNewAction.setOnClickListener(v -> {
            Intent intent = new Intent(NGOActionManagementActivity.this, CreateActionActivity.class);
            startActivity(intent);
        });



        //handles ListView item clicks for editing or deleting

        lvNGOActions.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            Action selectedAction = ngoActions.get(position);
            showActionOptionsDialog(selectedAction);
        });
    }


    //loads the NGO's actions into the ListView.


    private void loadNGOActions() {
        ngoActions = ngoManager.getAllActions();
        List<String> actionNames = ngoActions.stream().map(Action::getName).collect(Collectors.toList());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, actionNames );
        lvNGOActions.setAdapter(adapter);
    }

    /**
     * Shows a dialog with options to edit or delete an action.
     *
     * @param action The selected action.
     */


    private void showActionOptionsDialog(Action action) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Manage Action: " + action.getName())
            .setItems(new String[]{"Edit", "Delete"}, (dialog, which) -> {
                if (which == 0) {

                    // edit action

                    showEditActionDialog(action);
                } else if (which == 1) {

                    // delete action

                    boolean deleted = ngoManager.deleteAction(action.getId());
                    if (deleted) {
                        Toast.makeText(this, "Action deleted successfully.", Toast.LENGTH_SHORT).show();
                        loadNGOActions(); // Refresh the list
                    } else {
                        Toast.makeText(this, "Failed to delete action.", Toast.LENGTH_SHORT).show();
                    }
                }
            }).show();
    }

    /**
     * Shows a dialog to edit the selected action.
     *
     * @param action The action to edit.
     */


    private void showEditActionDialog(Action action) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_action, null);
        EditText etName = dialogView.findViewById(R.id.et_edit_action_name);
        EditText etDescription = dialogView.findViewById(R.id.et_edit_action_description);
        EditText etMaxParticipants = dialogView.findViewById(R.id.et_edit_action_max_participants);

        etName.setText(action.getName());
        etDescription.setText(action.getDescription());
        etMaxParticipants.setText(String.valueOf(action.getMaxParticipants()));

        new AlertDialog.Builder(this).setTitle("Edit Action").setView(dialogView).setPositiveButton("Save", (dialog, which) -> {
                String newName = etName.getText().toString().trim();
                String newDescription = etDescription.getText().toString().trim();
                int newMaxParticipants;
                try {
                    newMaxParticipants = Integer.parseInt(etMaxParticipants.getText().toString().trim());
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid max participants.", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean updated = ngoManager.editAction(action.getId(), newName, newDescription, newMaxParticipants);
                if (updated) {
                    Toast.makeText(this, "Action updated successfully.", Toast.LENGTH_SHORT).show();
                    loadNGOActions(); 
                } else {
                    Toast.makeText(this, "Failed to update action.", Toast.LENGTH_SHORT).show();
                }
            }).setNegativeButton("Cancel", null).show();


            
    }


}
