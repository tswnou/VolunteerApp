package com.example.volunteerapp;
import android.content.Intent;
import Android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.appcompat.app.AppCompatActivity;

public class RegistrationActivity extends AppCompatActivity{
    private EditText etUsername;
    private EditText etPassword;
    private Button btnRegister;
    private UserManager userManager;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        //initialize  views
        etUsername = findViewByld(R.id.et_username);
        etPassword = findViewByld(R.id.et_password);
        btnRegister = findViewByld(R.id.btn_register);

        //initialize UserManager
        userManager = new userManager(this);

        //Set button click listener
        btnRegister.setOnClickListener(new View.OnClickListener()){
            public void onClick(View v){
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if(username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(RegistrationActivity.this,"Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }


                boolean isRegisterd = userManager.registerUser(username , password);
                if(isRegisterd){
                    Toast.makeText(RegistrationActivity.this, "Registration Successfull",Toast.LENGTH_SHORT ).show();
                    Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }else{
                    Toast.makeText(RegistrationActivity.this, "User already exists", Toast.LENGTH_SHORT).show;
                }
            }
        }
    }
}
