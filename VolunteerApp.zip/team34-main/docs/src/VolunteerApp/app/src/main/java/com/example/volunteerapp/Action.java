package com.example.volunteerapp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Action{
    private int id;
    private String Title;
    private Date Date;
    private String Location;
    private String description;
    private int maxParticipants;
    private int currentParticipants;
    private int Availability;
    private List<Volunteer> volunteers;
    private boolean updated;

    public Action(int id, String Title, Date Date, String Location, String description, int maxParticipants, int currentParticipants, int Availability) {
        this.id = id;
        this.Title = Title;
        this.Date = Date;
        this.Location = Location;
        this.description = description;
        this.maxParticipants = maxParticipants;
        this.currentParticipants = currentParticipants;
        this.Availability = Availability;
        this.volunteers = new ArrayList<>();
        this.updated = false;

    }

    //get-set id
    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }



    //get-set title
    public String getTitle(){
        return Title;
    }

    public void setTitle(String Title){
        this.Title = Title;
    }



    //get-set Date
    public Date getDate(){
        return Date;
    }
    
    public void setDate(Date Date){
        this.Date = Date;
    }



    //get-set Location 
    public String getLocation(){
        return Location;
    }
    
    public void setLocation(String Location){
        this.Location = Location;
    }

    public String getDescription() {
        return description;
    }

    public int getMaxParticipants() {
        return maxParticipants;
    }

    public int getCurrentParticipants() {
        return currentParticipants;
    }

    public void setCurrentParticipants(int currentParticipants) {
        this.currentParticipants = currentParticipants;
    }

    //get-set Availability
    public int getAvailability(){
        return Availability;
    }
    
    public void setAvailability(int Availability){
        this.Availability = Availability;
    }


    public void Register(Volunteer volunteer) {
        if (Availability > 0){
            volunteers.add(volunteer);
            Availability--;
            System.out.println("The user " + volunteer.getName() + "has succesfully registered to : " + this.getTitle());
        } else {
            System.out.println("No availability for this action at this time");
        }
    }

    public void update() {
        this.updated = true;
        System.out.println("The action has been updated");
    }
}