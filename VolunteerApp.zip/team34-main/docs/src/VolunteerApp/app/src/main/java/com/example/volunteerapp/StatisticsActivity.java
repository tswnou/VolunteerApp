package com.example.volunteerapp;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.Map;

public class StatisticsActivity extends AppCompatActivity{
    private ListView IvStatistics;
    private AdminManager adminManager;
    private List<Action>approveActions;

    protected void  onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
        
        IvStatistics = findViewByld(R.id.lv_statistics);

        adminManager = new AdminManager();
        approveActions = getApprovedActions();
        loadStatistics();
    }

    private void loadStatistics(){
        Map<String, String> stats = adminManager.calculateStatistics(Approved);
        List<String> staList = stats.entrySet().stream()
        .map(entry -> entry.getKey() + ":" + entry.getValue())
        .toList();


        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this,
            android.R.layout.simple_list_item_1,
            staList
        );
        IvStatistics.setAdapter(adapter);

        private List<Action>getApprovedActions()
            return List.of()(
                new Action("1,"Tree Planing", 50,40)
            );
        


        }
    }
        
