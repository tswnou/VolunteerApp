public class User{
    private int id;
    private String username;
    private String password;


    public User(int id, String username, String password){

        this.id = id;
        this.username = username;
        this.password = password;

    }
    
    //get-set id

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    //get-set username
    public String getUsername(){
        return username;
    }

    public void setUsername(String username){
        this.username = username;
    }

    //get-set password
    public String getPassword(){
        return password;
    }

    public void setPassword(String password){
        this.password = password;
    }

    //elegxos an ta stoixia einai sosta 
    public boolean connection(String username, String password){
        if (username == null || password == null){
            throw new IllegalArgumentException("Username and password must not be null");
        }
        return this.username.equals(username) && this.password.equals(password);
    }

    //aposindesi xristi apo to sistima 
    public void disconnect(){
        System.out.println("The user " + username + " has disconnected");
    }
}