import java.util.ArrayList;
import java.util.List;

public class Admin extends User{

    private List<Action> actions;

    public Admin(int id, String username, String password){
        super(id, username, password);
        this.actions = new ArrayList<>();
    }

    //prosthiki neas drasis
    public void addAction(Action newAction){
        actions.add(newAction);
        System.out.println("The action " + newAction.getTitle() + " was added to your list");

    }

    //egrisi drasis
    public void AcceptAction(Action action){
        if (actions.contains(action)){
            action.update();
            System.out.println("The action " + action.getTitle() + " was accepted");
        } else {
            System.out.println("The action was not found.");

        }
    }


    //diagrafi drasis
   public void DeleteAction(Action action){
    if (actions.remove(action)){
        System.out.println("The action " + action.getTitle() + "was deleted.");
    } else {
        System.out.println("The action was not found.");
    }
   }

   //provoli olon ton draseon
   public void ShowActions(){

    System.out.println("The list of Actions: ");
    for (Action action : actions){
        System.out.println(" ~ " + action.getTitle() + " ,location :  " + action.getLocation() + " ,date: " + action.getDate() + " ,availability: " + action.getAvailability());


    }
   }

}
