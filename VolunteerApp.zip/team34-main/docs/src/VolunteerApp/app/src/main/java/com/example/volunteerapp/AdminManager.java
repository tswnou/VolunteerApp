package com.example.volunteerapp;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Action;

public class AdminManager{
    private List<Action> pendingActions;

    public AdminManager(){
        pendingActions = new ArrayList<>();
    }

    public void submitActionForApproval(Action action){
        pendingActions.add(action);
    }


    public List<Action>getPendingActions(){
        return pendingActions;
    }


    public boolean approveAction(String actionId){
        for(Action action : pendingActions){
            if(action.getId().equals(actionId)){
                pendingActions.remove(action);
                return true;
            }
        }
        return false;
    }  


    public boolean rejectAction(String actionid){
        for(Action action : pendingActions){
            if(action.getId().equals(actionid)){
                pendingActions.remove(action);
                return true;
            }
        }
        return false;
    }
}