package com.example.volunteerapp;

import android.content.Context;
import android.content.SharedPrefrences;
import android.util.Log;

public class UserManagement{

    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    public UserManager(Context context){
        this.sharedPreferences = context.getHaredPreferences(PREFS_NAME, Context.MODE_PRIVATE);

    }

    public boolean registerUser(String username, String password){
        if (sharedPreferences.contains(KEY_USERNAME)){
            Log.e("UserManager", "User already exists.")
            return false;
        }
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_USERNAME, username);
        editor.putString(KEY_PASSWORD, password);
        editor.apply();
        return true;
    }

    public boolean loginUser(String username , String password){
        String storedUsername = sharedPreferences.getString(KEY_USERNAME, null);
        String storedPassword = sharedPreferences.getString(KEY_PASSWORD, null);

        if(storedUsername != null && storedPassword != null){
            return storedUsername.equals(username) && storedPassword.equals(password);

        }
        return false;


    }

    public void clearUserData(){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}
