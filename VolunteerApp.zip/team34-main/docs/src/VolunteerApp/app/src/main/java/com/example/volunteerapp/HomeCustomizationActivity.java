package com.example.volunteerapp;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/**
 * Allows admins to customize the home menu options.
 */
public class HomeCustomizationActivity extends AppCompatActivity {
    private ListView lvMenuOptions;
    private Button btnAddMenuOption;
    private Button btnSaveChanges;
    private HomeMenuManager homeMenuManager;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_menu_customization_layout);
        lvMenuOptions=findViewById(R.id.lv_menu_options);
        btnAddMenuOption=findViewById(R.idbtn_add_menu_option);
        btnSaveChanges = findViewById(R.id.btn_save_changes);
        homeMenuManager = new HomeMenuManager();
        loadMenuOptions();
        btnAddMenuOption.setOnClickListener(v->{Toast.makeText(this, "Menu changes saved successfully!", Toast.LENGTH_SHORT).show();
        finish();
        });
        lvMenuOptions.setOnItemClickListener((parent, view, position, id)-> {String selectedOption = adapter.getItem(position);
        showEditOrDEleteDialog(selectedOption);
        });

    }

    /**
     * Loads the current menu options into the ListView.
     */
    private void loadMenuOptions() {
        List<String> menuOptions = homeMenuManager.getMenuOptions();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, menuOptions);
        lvMenuOptions.setAdapter(adapter);

    }

    /**
     * Displays a dialog to add a new menu option.
     */
    private void showAddOptionDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_option, null);
        EditText etNewOption = dialogView.findViewById(R.id.et_new_menu_option);
        new AlertDialog.Builder(this).setTitle("Add New Menu Option").setView(dialogView).setPositiveButton("Add", (dialog, which) -> {
            String newOption = etNewOption.getText().toString().trim();
            if(!newOption.isEmpty() && homeMenuManager.addMenuOption(newOption)) {
                Toast.makeText(this, "Option added successfully!", Toast.LENGTH_SHORT).show();
                loadMenuOptions();

            }
            else {
                Toast.makeText(this, "Option already exists or is invalid.", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Cancel", null).show();
    }
}
/**
 * Displays a dialog to edit or delete a menu option.
 *
 * @param selectedOption The selected menu option.
 */




private void showEditOrDeleteDialog(String selectedOption){
    new AlertDialog.Builder(this)
            .setTitle("Manage Option " : + selectedOption)
      .setItems(new String[]{"Edit, "Delete"}, (dialog, which)-> {
    if(which == 0){
        showEditOptionDialog(selectedOption);
    }else if(which == 1){
        boolean removed = homeMenuManager.removeMenuOption(selectedOption);
        if(removed){
            Toast.makeText(this,"Option deleted successfully" , Toast.LENGTH_SHORT).show();
            loadMenuOptions();
        }else{
            Toast.makeText(thid, " Failed to delete option", Toast.LENGTH_SHORT).show();
        }
    }
})
         .show();
}

/**
 * Displays a dialog to edit a menu option.
 *
 * @param oldOption The option to edit.
 */

private void showEditOptionDialog(String oldOption) {
    View dialogView = getLayoutInflanter().inflate(R.layout.dialog_add_option, null);
    EditText etEditOption = dialogView.findViewById(R.id.et_new_menu_option);
    etEditOption.setText(oldOption);

    new AlertDialog.Builder(this)
            .setTitle("Edit Menu Option")
            .setView(dialogView)
            .setPositiveButton("Save", (dialog, which) -> {
                String newOption = etEditOption.getText().toString().trim();
                if (!newOption.isEmpty() && homeMenuManager.updateMenuOption(oldOption, newOption)) {
                    Toast.makeText(this, "Option updated successfully", Toast.LENGTH_SHORT).show();
                    loadMenuOptions();
                } else {
                    Toast.makeText(this, "Option already exists or is invalid", Toast..LENGTH_SHORT).
                    show();

                }


            })
            .setNegativeButton("Cansel", null)
            .show();


    }
}
