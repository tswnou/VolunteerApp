package com.example.volunteerapp;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CreateActionActivity extends AppCompatActivity{
    private EditText etActionName;
    private EditText etActionDescription;
    private EditText etMaxParticipants;
    private Button btnSubmitAction;
    private AdminManager adminManager;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acivity_create_action);

        etActionName = findViewByld(R.id.et_action_name);
        etActionDescription = findViewByld(R.id.et_action_description);
        etMaxParticipants = findViewByld(R.id.et_max_participants);
        btnSubmitAction = findViewByld(R.id.btn_submit_action);

        adminManager= new AdminManager();

        btnSubmitAction.setOnClickListener(v -> {
            String name= etActionName.getText().toString().trim();
            String description = etActionDescription.getText().toString().trim();
            String maxParticipantsText= etMaxParticipants.getText().toString().trim();

            if(name.isEmpty() || description.isEmpty() || maxParticipantsText.isEmpty()){
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int maxParticipants;
            try{
                maxParticipants = Integer.parseInt(maxParticipantsText);     
            }catch (NumberFormatException e){
                Toast.makeText(this, "Invalid number for max participants", Toast.LENGTH_SHORT).show();
                return;
            }


            Action newAction = new Action(
                String.valueOf(System.currentTimeMilis()),
                name,
                description,
                maxParticipants,
                0
            );

            adminManager.submitActionForApproval(newAction);
            Toast.makeText(this, "Action submitted for approval", Toast.LENGTH_SHORT).show();
            finish();
        


        });
        


        }
}