import org.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class UserSystemTest {
    @Test
    void testCreateUser() {
        userSystem system = new userSystem();
        boolean isCreated = system.createUser(1, "Christina Karagianni", "Pass123");
        assertTrue(isCreated, "User creation  should return true");
    }

    @Test
    void testIsValidPassword() {
        userSystem system = new userSystem();
        assertTrue(system.isValidPassword("valid123"), "Password should be valid.");
        assertFalse(system.isValidPassword("invalid123"), "Password should be invalid.");

    }

    @Test
    void testIsValidUsername() {
        userSystem system = new userSystem();
        assertTrue(system.isValidUsername("Christina123"), "Username should be valid");
        assertFalse(system.isValidUsername("christina"), "Username should be invalid");
    }

    @Test
    void testUserExist() {
        userSystem system = new userSystem();
        system.createUser(1, "Christina123", "pass123");
        assertTrue(system.UserExist("Christina123"), "User should exist");
        assertFalse(system.UserExist("christina"), "User should not exist");

    }

    @Test
    void testLogin() {
        userSystem system = new userSystem();
        system.createUser(1, "Christina123", "pass123");
        assertTrue(system.login("Christina123", "pass123"), "Login should be a success");
        assertFalse(system.login("Christina123", "pass1234"), "Login should Fail");

    }
}