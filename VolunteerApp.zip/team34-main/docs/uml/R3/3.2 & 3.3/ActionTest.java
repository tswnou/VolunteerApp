import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class ActionTest {

    private Action action;
    private Volunteer vol1;
    private Volunteer vol2;

    @BeforeEach
    void setup() {
        action = new Action(1, "Tree planting", new Date(), "Penteli", 2);
        vol1 = new Volunteer(1, "Christina123", "pass123",  "christina@gmail.com", "Christina Karagianni");
        vol2 = new Volunteer(2, "Ioanna123", "pass456", "ioanna@gmail.com", "Ioanna Tswnou");
    }

    @Test
    void testGetAndSet() {
        action.setId(10);
        assertEquals(10, action.getId());
        action.setTitle("Beach Cleanup");
        assertEquals("Beach Cleanup", action.getTitle());
        Date newDate = new Date();
        action.setDate(newDate);
        assertEquals(newDate, action.getDate());
        action.setLocation("Beach");
        assertEquals("Beach", action.getLocation());
        action.setAvailability(5);
        assertEquals(5, action.getAvailability());

    }

    @Test
    void testLimitedRegister() {
        action.Register(vol1);
        assertEquals(1, action.getAvailability(), "Availability should -1 after a volunteer registers");
        action.Register(vol2);
        assertEquals(0, action.getAvailability(), "Availability should 0 after a volunteer registers");
        
    }

    @Test
    void testRegisterWOAvailability() {
        action.Register(vol1);
        action.Register(vol2);
        Volunteer vol3 = new Volunteer(3, "Alexia123", "pass789", "alexia@gmail.com", "Alexia Ntetsika");
        assertEquals(0, action.getAvailability(), "Availability should be 0 even before registering.");
        action.Register(vol3);
        assertEquals(0, action.getAvailability(), "Availability should still be 0 after failed registration attempt");
    }

    @Test
    void testUpdateMethod() {
        action.update();
    }
}