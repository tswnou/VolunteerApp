import org.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.Date;

class AdminTest {

    @Test
    void testAddAction() {
        Admin admin = new Admin(1, "admin", "pass");
        Action action = new Action(1, "Tree Planting", new Date(), "Penteli", 10);

        admin.addAction(action);
        assertTrue(admin.ShowActions().contains(action), "Action shpuld be added to admin's list");

    }

    @Test
    void testAcceptAction() {
        Admin admin = new Admin(1, "admin", "pass");
        Action action = new Action(1, "Tree Planting", new Date(), "Penteli", 10);

        admin.addAction(action);
        admin.AcceptAction(action);
        assertTrue(action.update(), "Action should be marked as accepted");

    }

    @Test
    void testDeleteAction() {
        Admin admin = new Admin(1, "admin", "pass");
        Action action = new Action(1, "Tree Planting", new Date(), "Penteli", 10);

        admin.addAction(action);
        admin.DeleteAction(action);
        assertFalse(admin.ShowActions().contains(action), "Action should be removed from admin's list");
    }
}